java -jar TEMPLE_v1.0.jar Kr.txt alignment_171.txt region_171.txt 1 1 2
