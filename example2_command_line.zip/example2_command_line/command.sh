java -jar TEMPLE_v1.0.jar all_pwm.txt alignment_example2.fas region_example2.txt 1 1 2
