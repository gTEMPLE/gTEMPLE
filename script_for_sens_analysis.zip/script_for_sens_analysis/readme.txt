
This scripts can be used to run TEMPLE on a large number of genomic regions
It starts by extracting alignments for each ChIP seq peak using a small C++ binary (extractor)
Then it uses a loop over all generated alignments to execute TEMPLE over each alignment
Finally, it concatenates all the results together
The script has to be executed like 
>bash launcher.sh $1 $2,
where $1 is the name of the TF/PWM and $2 is the chromosome arm (region files have been splitted by chromosome arms)
example: >bash launcher.sh sens 2L
It requires that full-genome alignments of the DPGP are located at the path indicated at line 29 of the launcher.sh file (Files with full genomes should also be split by chromosome)
Full genomes can be downloaded from the DPGP homepage (www.dpgp.org)
The C++ binary "extractor" can be compiled from source using the following command (in the extractor_src directory)
>g++ -o extractor main.cpp



