
#############################################################################################################################################################################
#
#	This scripts can be used to run TEMPLE on a large number of genomic regions
#	It starts by extracting alignments for each ChIP seq peak using a small C++ binary (extractor)
#	Then it uses a loop over all generated alignments to execute TEMPLE over each alignment
#	Finally, it concatenates all the results together
#	The script has to be executed like 
#	>bash launcher.sh $1 $2,
#	where $1 is the name of the TF/PWM and $2 is the chromosome arm (region files have been splitted by chromosome arms)
#	example: >bash launcher.sh sens 2L
#	It requires that full-genome alignments of the DPGP are located at the path indicated at line 29 (Files with full genomes should also be split by chromosome)
#	Full genomes can be downloaded from the DPGP homepage (www.dpgp.org)
#	The C++ binary "extractor" can be compiled from source using the following command (in the extractor_src directory)
#	>g++ -o extractor main.cpp
#
#############################################################################################################################################################################



set -x
#trap read DEBUG

#Create file system
mkdir $1_$2
mkdir $1_$2/alignments
mkdir $1_$2/regions

cp gTEMPLE_* $1_$2

#Make sure the extractor binary is executable
chmod u+x extractor;
#change path to fasta file. The path to the full chromosome alignments (first argument)  should be updated to match the location on your computer
./extractor /Users/stefan/largeData/ZI_FR_sim_clean/FR_ZI_sim_${2}.fas encodeData/$1/region_${1}_${2}

mv alignment_* $1_$2/alignments/
mv region_* $1_$2/regions/

cd $1_$2
mkdir RESULTS

#Loop over each alignment
for file in `ls alignments`

do

peak=${file:9};
echo $peak;

#Execute TEMPLE in the 2-population mode, allowing for 50% of missing data at each site
java -jar gTEMPLE_2.jar ../encodeData/$1/motif/${1}.pwm alignments/alignment$peak regions/region$peak 1 0.5 2

mv france* RESULTS/results${peak};

done

mkdir concat;

#Concatenate results
for file in `ls RESULTS`

do

cp RESULTS/$file/*/*MUTATION* concat/mut_$file
cp RESULTS/$file/*/*TFBSuniq* concat/tfbs_$file
cp RESULTS/$file/*/*TFBSbyseq* concat/tfbsBS_$file
cp RESULTS/$file/*/*REGION* concat/reg_$file

done

#check that the number of columns is stll correct
cat concat/mut_*  | awk -F "," 'NF==32' | head -1 > mutation_level_header
cat concat/tfbs_* | awk -F "," 'NF==17' | head -1 > tfbs_level_header
cat concat/tfbsBS_* | awk -F "," 'NF==15' | head -1 > tfbsBS_level_header
cat concat/reg_*  | awk -F "," 'NF==14' | head -1 > region_level_header

cat concat/mut_*  | awk -F "," 'NF==33' | grep -v Chr > mutation_level
#There's an additional "," after the last column that we need to remove. For now we increase the numbers of columns to 33 in the awk filter
cat concat/tfbs_* | awk -F "," 'NF==17' | grep -v Chr > tfbs_level
cat concat/tfbsBS_* | awk -F "," 'NF==15' | grep -v Chr > tfbsBS_level
cat concat/reg_*  | awk -F "," 'NF==14' | grep -v Chr > region_level

cat mutation_level_header mutation_level > mutation_output_$2.csv
cat tfbs_level_header tfbs_level > tfbs_output_$2.csv
cat tfbsBS_level_header tfbsBS_level > tfbsBS_output_$2.csv
cat region_level_header region_level > region_output_$2.csv

rm *_level*
rm -r concat;

