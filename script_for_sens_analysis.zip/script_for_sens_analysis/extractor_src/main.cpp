#include<iostream> //include standard C++ library to allow printing stuff on the terminal
#include<fstream>  //include standard C++ library to allow printing stuff on the terminal
#include<vector>   //include standard C++ library to allow the use of vectors
#include<stdlib.h> //include standard C library to allow the use of atoi (conversion of char to integers)

using namespace std;//if you uncomment this line you are not forced anymore to write "" every time in the code

vector< vector<string> > readModencodeFile(string pathToModencode, ifstream *descriptor);

int main(int argc, char *argv[])
{
	int sizePop1 = 8;
	int sizePop2 = 27;
	string namePop1 = "france";
	string namePop2 = "zambia";

	//Establishing connexion to the fasta file
	string pathToFastaFile = argv[1];     //Here I store the path to the fastaFile in a variable of type string
	ifstream myConnexionToTheFastaFile;   //Here I define a connexion to a file which I didn't specified yet
	myConnexionToTheFastaFile.open(pathToFastaFile.c_str());  //Here I specify the path to the fastaFile//
//	cerr << myConnexionToTheFastaFile.good() << endl; //Test whether the connexion is good//

	//Establishing connexio to the encode file
	string pathToEncode = argv[2];
	ifstream myConnexionToEncode; 
	myConnexionToEncode.open(pathToEncode.c_str());
	vector <vector<string> > encodeData = readModencodeFile(pathToEncode, &myConnexionToEncode);

	//Variables for extraction
	string currentString;
	vector<string> sequenceNames;
	vector<string> sequences;
	
	//Read in sequence data	
	while(myConnexionToTheFastaFile >> currentString)
	{
		//cout << currentString.substr(0,1) << endl;
		if(currentString.substr(0,1) == ">")
		{
			currentString.erase(currentString.begin()+0);
			sequenceNames.push_back(currentString);
		}
		else
		{
			sequences.push_back(currentString);
		}
	}


	for(int i=1; i<encodeData.size(); i++)
	{
		string nameOfAlignment = "alignment_" + encodeData[i][4] + ".txt";
		string nameOfRegion = "region_" + encodeData[i][4] + ".txt";

		ofstream toAlignment(nameOfAlignment.c_str());
		ofstream toRegion(nameOfRegion.c_str());

		//Get coordinates
		int start = atoi(encodeData[i][2].c_str()) - 1 ;//here i get the second argument from the command line, convert it to an integer and convert to zero-based indexing
		int stop  = atoi(encodeData[i][3].c_str()) - 1 ;//here i get the third argument .....idem.....
		int length = stop - start + 1; //here I calculate the length of the region that will be extracted, I need it for string.substr(start, length)
		//Get relative 1 based coord. for region file
		int rel_start = 1;
		int rel_stop = stop - start + 1; 


		//Formatting alignment//
		toAlignment << "//" << namePop1 << endl;

		//Formatting pop1
		for(int j=0; j<sizePop1; j++)
		{
			//Formatting sequence names
			string seqName = ">" + encodeData[i][1] + "_" + encodeData[i][2] + "_" + encodeData[i][3] + "_" + sequenceNames[j];
			toAlignment << seqName << endl;                     //Print the name of the sequence

			//Extract genomic region
			toAlignment << sequences[j].substr(start,length) << endl;       //Print the portion of the full chromosome defined by start and length
		}

		toAlignment << "//" << namePop2 << endl;

		//Formatting popr2
		for(int j=sizePop1; j<sizePop1 + sizePop2; j++)//OUTGROUP MUST BE LAST SEQUENCE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		{
			//Formatting sequence names
			string seqName = ">" + encodeData[i][1] + "_" + encodeData[i][2] + "_" + encodeData[i][3] + "_" + sequenceNames[j];
			toAlignment << seqName << endl;                     //Print the name of the sequence

			//Extract genomic region
			toAlignment << sequences[j].substr(start,length) << endl;       //Print the portion of the full chromosome defined by start and length
		}

		//Formatting outgroup name
		string seqName = ">OUTGR" + encodeData[i][1] + "_" + encodeData[i][2] + "_" + encodeData[i][3] + "_" + sequenceNames[sizePop1+sizePop2];
		toAlignment << seqName << endl;                     //Print the name of the sequence

		//Extract genomic region
		toAlignment << sequences[sizePop1+sizePop2].substr(start,length) << endl;       //Print the portion of the full chromosome defined by start and length



		toAlignment << "//" << endl;

		toRegion << "set	chr	start	stop	id	pwm" << endl;
		toRegion << encodeData[i][0] << "\t"
			<< encodeData[i][1] << "\t"
			<< rel_start << "\t"
			<< rel_stop << "\t"
			<< encodeData[i][4] << "\t"
			<< encodeData[i][5] << endl;

		toAlignment.close();
		toRegion.close();

	}


	return 0;                        //I quit the program//

}

vector< vector<string> > readModencodeFile(string pathToModencode, ifstream *myConnexionToEncode)
{
	vector< vector<string> > encodeData;
	string temp;
	vector<string> vTemp;
	int i=0;

	while(*myConnexionToEncode >> temp)
	{
		i++;
		vTemp.push_back(temp);

		if(i==6)
		{
			i=0;
			encodeData.push_back(vTemp);
			vTemp.clear();
		}

	}

	for(int j=0; j<encodeData.size(); j++)
	{
		for(int k=0; k<encodeData[0].size(); k++)
		{
			cout << encodeData[j][k] << "\t";
		}

		cout << endl;
	}

	return encodeData;


}
